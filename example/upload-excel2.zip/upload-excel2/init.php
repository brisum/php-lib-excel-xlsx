<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('STARTTIME', microtime(true)); 
define('DIR_UPLOAD', realpath(dirname(__FILE__) . '/upload')); 

define( '_JEXEC', 1 );
define( 'DS', DIRECTORY_SEPARATOR );
define('JPATH_BASE', realpath(dirname(__FILE__) . '/../../'));

require_once ( JPATH_BASE .DS.'configuration.php' );
$conf = new JConfig();
define('DB_HOST', $conf->host);
define('DB_USER', $conf->user);
define('DB_PASSWORD', $conf->password);
define('DB_DB', $conf->db);
define('DBT_PRICE', 'bsm_price');
define('DBT_STORE_AK', 'bsm_store_ak');
unset($conf);

require_once('functions.php');

require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

$mainframe =& JFactory::getApplication('administrator');
$mainframe->initialise();

$user =& JFactory::getUser();
if ( 'Super Administrator' != $user->get('usertype') ) {
    die('error access');
}
