<?php

class BsmXlsx {
    private $filepath = null;
    private $dir = null;
    private $startRow = 0;
    private $endRow = 0;
    private $startCol = 0;
    private $endCol = 0;
    private $sheet = 1;

    public function __construct($filepath, $dir) {
        $this->filepath = $filepath;
        $this->dir = $dir;
    }

    public function extract() {
        if ( !file_exists($this->filepath) ) {
            throw new Exception("File not exist", 1);
        }

        if ( file_exists($this->dir) ) {
            BsmFileHelper::rmdir($this->dir);
        }
        if ( !mkdir($this->dir, 0777, true) ) {
            throw new Exception("Can't create temp folder", 1);
        }

        $zip = new ZipArchive();
        $zip->open($this->filepath);
        $zip->extractTo($this->dir);
    }

    public function clear() {
        BsmFileHelper::rmdir($this->dir);
    }

    public function setRows($startRow, $chunkSize) {
        $this->startRow = $startRow; // start from 1;
        $this->endRow = $startRow + $chunkSize;
    }

    public function setCols($startCol, $chunkSize) {
        $this->startCol = $startCol - 1; // start from 0;
        $this->endCol = $this->startCol + $chunkSize;
    }

    public function setSheet($sheet) {
        $this->sheet = (int) $sheet;
    }

    public function data() {
        $fileStrings = $this->dir . '/xl/sharedStrings.xml';
        $fileSheet = $this->dir . '/xl/worksheets/sheet' . $this->sheet . '.xml';
        $reader = new XMLReader();
        $xmlRows = array();
        $searchStrings = array();
        $strings = array();
        $data = array();

        if ( !file_exists($fileStrings) ) {
            throw new Exception("Can't open strings file: " . $fileStrings, 1);
        }
        if ( !file_exists($fileSheet) ) {
            throw new Exception("Can't open strings file: " . $fileSheet, 1);
        }

        $reader->open($fileSheet);
        $tag = 'row';
        $nRow = 1;
        $isParse = true; 
        while ( $isParse && $reader->read() ) {
            while ( $isParse && $tag === $reader->name ) {
                if ( $nRow >= $this->endRow ) {
                    $isParse = false;
                }

                if ( $nRow >= $this->startRow && $nRow < $this->endRow ) {
                    $xmlRow = new SimpleXMLElement($reader->readOuterXML());

                    $data[$nRow] = array();

                    for ( $nCol = $this->startCol; $nCol < $this->endCol; $nCol++ ) {
                        $xmlCell = $xmlRow->c[$nCol];
                        $v = (string) $xmlCell->v;
                        $nameCol = (string) $xmlCell['r'];

                        $nameCol = rtrim($nameCol, '1234567890');

                        $data[$nRow][$nameCol] = $xmlCell;

                        // If it has a "t" (type?) of "s" (string?), use the value to look up string value
                        if ( isset($xmlCell['t']) && $xmlCell['t'] == 's') {
                            $searchStrings[$v] = true;
                        }

                        unset($xmlCell);
                    }

                    unset($xmlRow);
                }

                $reader->next($tag);
                $nRow += 1;
            }
        }

        ksort($searchStrings);
        end($searchStrings);
        $lastKey = key($searchStrings);

        $reader->open($fileStrings);
        $tag = 'si';
        $count = 0;
        $isParse = true;
        while ( $isParse && $reader->read() ) {
            while ( $isParse && $tag === $reader->name ) {
                if ( $count > $lastKey ) {
                    $isParse = false;
                }

                if ( isset($searchStrings[$count]) ) {
                    $elem = new SimpleXMLElement($reader->readOuterXML());

                    $strings[$count] = (string)$elem->t;

                    unset($elem);
                }

                $reader->next($tag);
                $count += 1;
            }
        }

        foreach ( $data as $nRow => $xmlRow ) {
            foreach ( $xmlRow as $nCol => $xmlCell ) {
                $val = '';
                $v = (string) $xmlCell->v;

                // If it has a "t" (type?) of "s" (string?), use the value to look up string value
                if ( isset($xmlCell['t']) && $xmlCell['t'] == 's') {
                    $val = $strings[$v];
                } elseif ( isset($xmlCell['t']) && $xmlCell['t'] == 'str') {
                    $val = (string) $v;
                } elseif ( !isset($xmlCell['t']) ) {
                    $val = (string) $v;
                }

                // elseif ( !$v ) {
                //     $r = (string) $xmlCell['r'];
                //     if ( isset($images[$r]) ) {
                //         $v = $images[$r];
                //     }
                // }

                $data[$nRow][$nCol] = trim($val);

                unset($xmlCell);
            }

            unset($xmlRow);
        }

        unset($strings);
        return $data;
    }

    

    public static function parseImages($dir, $url) {
        $images = array();

         // parse image rId => imageTarget
        $drawings_rel = simplexml_load_file($dir . '/xl/drawings/_rels/drawing1.xml.rels');
        foreach ( $drawings_rel->Relationship as $imgRel ) {
          $rId = (string) $imgRel['Id'];
          $imgTarget = (string) $imgRel['Target'];

          $images[$rId] = str_replace('..', $url, $imgTarget);
        }
        unset($drawings_rel);


        // parse cell => rId, and replace rId to cell;
        $drawings = simplexml_load_file($dir . '/xl/drawings/drawing1.xml', 'SimpleXMLElement', 0, 'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing');
        $drawings->registerXPathNamespace('a', 'http://schemas.openxmlformats.org/drawingml/2006/main');
        foreach ( $drawings->twoCellAnchor as $imgInfo ) {
          $cell = 'G' . (1 + ((string)$imgInfo->from->row));

          $blipFill = $imgInfo->pic->blipFill;
          $blipFill = $blipFill->children('http://schemas.openxmlformats.org/drawingml/2006/main');

          $blip = $blipFill->blip;
          $blip->registerXPathNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');

          $rId = $blip->xpath('@r:embed');
          $rId = (string)$rId[0]['embed'];

          if ( isset($images[$rId]) ) {
            $images[$cell] = $images[$rId];
            unset($images[$rId]);
          }
        }
        unset($drawings);

        return $images;
    }
}
