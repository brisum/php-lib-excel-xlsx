<?php
/**
 * PHP versions 5
 *
 * XML parser   
 *
 * @copyright	Copyright 2008, Tedor.
 * @package		Tedor labs
 * @author		Tedor(vetalyi@gmail.com)
 * @version		1.0
 * @link 		http://lightxml.googlecode.com
 * @license		http://www.opensource.org/licenses/bsd-license.php BSD License
 */

class XML_parser
{
	/**
	 * XML данные.
	 *
	 * @var string
	 * @access public
	 */
	var $data;
	
	/**
	 * Распарсеные XML данные.
	 *
	 * @var array
	 * @access public
	 */
	var $parse;
	
	/**
	 * Метод по которому будет парсится XML и создаватся массив.
	 * Бывает 2 типа, 'text' и 'array':
	 * text - Создается одномерный массив, ключ каждого елемента это путь к елементу XML.
	 * array - Содается многомерный массив, где вложеность определяется структурой XML.
	 * По умолчанию 'text'.
	 * 
	 * @var text
	 * @access public
	 */
	var $separated_type = 'text';
	
	/**
	 * Когда используется метод парсинга 'text', эта переменная определяет каким символом будет разделятся путь, в каждом ключе.
	 * 
	 * @var text
	 * @access public
	 */
	var $separator = '|';
	
	/**
	 * Текущий путь.
	 * 
	 * @var text
	 * @access public
	 */
	var $path = '';
	
	/**
	 * Символ, которым разделяется введеный путь.
	 * По умолчанию '/'.
	 * 
	 * @var text
	 * @access public
	 */
	var $path_separator = '/';

	/**
	 * Временный массив.
	 * 
	 * @var array
	 * @access private
	 */
	private	$__tmp = array();
	
	/**
	 * Временный текущий ключ.
	 * 
	 * @var string
	 * @access private
	 */
	private $__str_keys = "";

	/**
	 * Constructor. Получает данные из файла или ссылки.
	 *
	 * @param string $in Текст или ссылка. Не обязательный параметр.
	 * @param string $type Тип первого параметра, это может быть 'link' или 'data'. Не обязательный параметр. По умолчанию 'link'.
	 */
	public function __construct($in = null, $type = 'link')
	{
		if($in)
		{
			if($type == 'link')
			{
				$this->setDataByLink($in);
			}
			elseif($type == 'data')
			{
				$this->data = $in;
			}
			$this->parse();
		}		
	}

	/**
	 * Получает содержимое из указаного линка.
	 *
	 * @param string $link Ссылка или путь к файлу.
	 */
	public function setDataByLink($link)
	{
		$this->data = file_get_contents($link);
	}
	
	/**
	 * Получает содержимое из указаного текста.
	 *
	 * @param string $data Текст.
	 */
	public function setData($data)
	{
		$this->data = $data;
	}
	
	/**
	 * Парсинг данных.
	 *
	 */
	public function parse()
	{
		if(!empty($this->parse)) unset($this->parse);
		$data = $this->data;
		$parser = xml_parser_create();
		xml_set_object($parser, $this);
		xml_set_element_handler($parser, '__StartTag', '__EndTag');
		xml_set_character_data_handler($parser, '__DataTag');
		xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, false);
		xml_parse($parser, $this->data);

		$this->__parse();
	}

	/**
	 * Парсинг данных. Фильтрация данных, и создание структуры.
	 *
	 */
	private function __parse()
	{
		if($this->separated_type == 'text')
		{
			foreach($this->parse as $k=>$v)
			{
				if(count($v) == 1)
				{
					unset($this->parse[$k][0]);
					$this->parse[$k] = $v[0];
				}
			}
		}
		elseif($this->separated_type == 'array')
		{
			foreach($this->parse as $k=>$v)
			{
				$k_array = explode($this->separator, $k);
				$k_str = '$parse';
				foreach($k_array as $kk=>$vv)
				{
					$k_str .= "['".$vv."']";
				}
				$k_str .= '[\'tagData\'] = $v;';
				eval($k_str);
			}
			unset($this->parse);
			$this->parse = $parse;
		}
	}

	/**
	 * Берет тег который открывает, все его параметры.
	 *
	 * @param string $parser Указатель на текущий парсер.
	 * @param string $name Имя тега.
	 * @param string $attr Атрибуты тега.
	 */
	private function __StartTag($parser, $name, $attr)
	{
		$this->__tmp[$name] = array();

		$this->__str_keys = "";
		foreach($this->__tmp as $k=>$v)
		{
			$this->__str_keys .= $k.$this->separator;
		}
		$this->__str_keys = rtrim($this->__str_keys, $this->separator);

		$this->parse[$this->__str_keys][] = $attr;
	}

	/**
	 * Берет тег который закрывает.
	 *
	 * @param string $parser Указатель на текущий парсер.
	 * @param string $name Имя тега.
	 */
	private function __EndTag($parser, $name)
	{
		end($this->__tmp);
		if (key($this->__tmp) == $name)
		{
			array_pop($this->__tmp);
		}
	}

	/**
	 * Берет содержимое тега.
	 *
	 * @param string $parser Указатель на текущий парсер.
	 * @param string $value Содержимое.
	 */
	private function __DataTag($parser, $value)
	{
		if(trim($value) != '')
		{
			$this->parse[$this->__str_keys][count($this->parse[$this->__str_keys])-1]['value'] = trim($value);
		}
	}

	/**
	 * Устанавливает текущий путь.
	 *
	 * @param string $path DOM путь XML файла.
	 */	
	public function setPath($path)
	{
		$this->path = $this->getCurrentPath($path);
	}

	/**
	 * Устанавливает метод парсинга.
	 *
	 * @param string Метод парсинга 'text' или 'array'.
	 */	
	public function setMethodParse($type = 'text')
	{
		$this->separated_type = $type;
		$this->parse();
	}

	/**
	 * Обьединяет указаные пути и возвращает результат, если второй параметр не указан, тогда пытается обьеденить с текущим.
	 *
	 * @param string $path1 DOM путь XML файла.
	 * @param string $path2 DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return string
	 */	
	public function combinedPath($path1, $path2 = null)
	{
		if($path2 == null && !empty($this->path))
		{
			return $this->path_separator.trim($this->path, $this->path_separator).$this->path_separator.trim($path1, $this->path_separator);
		}
		elseif($path2 != null)
		{
			return $this->path_separator.trim($path1, $this->path_separator).$this->path_separator.trim($path2, $this->path_separator);
		}
		else
		{
			return "";
		}
	}

	/**
	 * Вычисляет текущий установленый путь, и возвращает результат.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return string
	 */
	public function getCurrentPath($path = null)
	{
		if($path == null && !empty($this->path))
		{
			return trim($this->path, $this->path_separator);
		}

		if($path != null)
		{

			if($path{0} == $this->path_separator)
			{
				$path_type = "absolute";
			}
			else
			{
				$path_type = "relative";
			}

			$path_trim = trim($this->path, $this->path_separator);

			$path_tmp = "";
			if($path_type == "relative")
			{
				$path_array = explode($this->path_separator, $this->path_separator.$path_trim.$this->path_separator.$path);
			}
			elseif($path_type == "absolute")
			{
				$path_array = explode($this->path_separator, $path);
			}

			$i = 1;
			foreach($path_array as $k=>$v)
			{

				if($v == "..")
				{
					unset($path_array[$k-($i+($i-1))]);
					unset($path_array[$k]);
					$i++;
				}
				else
				{
					$i = 1;
				}
			}

			$path = implode($this->path_separator, $path_array);
			$path = trim($path, $this->path_separator);
			return $path;
		}
	}

	/**
	 * Возвращает содержимое указаного или текущего тега, его значение и все его параметры.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getNode($path = null)
	{
		$path = $this->getCurrentPath($path);

		if(!empty($path))
		{
			if($this->separated_type == 'text')
			{
				return $this->parse[str_replace($this->path_separator, $this->separator, $path)];
			}
			elseif($this->separated_type == 'array')
			{
				$k_array = explode($this->path_separator, $path);
				$k_str = 'return $this->parse';
				foreach($k_array as $kk=>$vv)
				{
					$k_str .= "['".$vv."']";
				}
				$k_str .= '[\'tagData\'];';
				return eval($k_str);
			}
		}
		else
		{
			return array();
		}
	}

	/**
	 * Возвращает содержимое, первого елемента, указаного или текущего тега, его значение и все его параметры.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getFirstNode($path = null)
	{
		$parse = $this->getNode($path);
		return $parse[0];
	}

	/**
	 * Возвращает содержимое, последнего елемента, указаного или текущего тега, его значение и все его параметры.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getLastNode($path = null)
	{
		$parse = $this->getNode($path);
		return $parse[count($parse)-1];
	}

	/**
	 * Возвращает содержимое указаного или текущего тега, который находится на уровень выше, его значение и все его параметры.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getParentNode($path = null)
	{
		$path = $this->combinedPath($path, "..".$this->path_separator);
		return $this->getNode($path);
	}

	/**
	 * Возвращает имена дочерных тегов.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getTags($path = null)
	{
		$tags = array();
		$path = $this->getCurrentPath($path);

		if(!empty($path))
		{
			if($this->separated_type == 'text')
			{
				$path_format = str_replace($this->path_separator, $this->separator, $path);
				$pattern = "|^".preg_quote($path_format).".*$|i";

				foreach($this->parse as $k=>$v)
				{
					if(preg_match($pattern, $k))
					{
						$k .= $this->separator; // TODO Regexp
						preg_match_all("/".preg_quote($path_format)."".preg_quote($this->separator)."(.*)".preg_quote($this->separator).".*/iUs", $k, $k_out_array);
						$k_out = $k_out_array[1][0];

						if(!empty($k_out))
						{
							if(!in_array($k_out, $tags)) $tags[] = $k_out;
						}
					}
				}
			}
			elseif($this->separated_type == 'array')
			{
				$k_array = explode($this->path_separator, $path);
				$k_str = 'return $this->parse';
				foreach($k_array as $kk=>$vv)
				{
					$k_str .= "['".$vv."']";
				}
				$k_str .= ';';
				$data = eval($k_str);
				foreach($data as $k=>$v)
				{
					if($k != "tagData") $tags[] = $k;
				}
			}
		}
		return $tags;
	}

	/**
	 * Алиас getTags().
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getChildTags($path = null)
	{
		return $this->getTags($path);
	}

	/**
	 * Возвращает имена дочерных тегов, которые находятся на уровень выше.
	 *
	 * @param string $path DOM путь XML файла. Не обязательный параметр.
	 * 
	 * @return array
	 */
	public function getParentTags($path = null)
	{
		$path = $this->combinedPath($path, "..".$this->path_separator);
		return $this->getTags($path);
	}

}

?>