<?php

class FileManager {
    private $dirUpload = null;
    public function __construct($dirUpload) {
        $this->dirUpload = $dirUpload;
    }

    public function response() {
        $hash = '';
        $fileUpload = null;
        $log = $this->dirUpload . '/html5upload.php';

        openlog($log, LOG_PID | LOG_PERROR, LOG_LOCAL0);

        if ( isset($_SERVER["HTTP_UPLOAD_ID"]) ) {
            $hash = $_SERVER["HTTP_UPLOAD_ID"] ;
        }
        if ( !preg_match("/^[0123456789abcdef]{32}_[0-9]{1,2}$/i", $hash) ) {
            syslog(LOG_INFO, "Uploading chunk. Wrong hash ".$hash);
            header("HTTP/1.0 500 Internal Server Error");
            print "Wrong session hash.";

            closelog();
            return;
        }

        $fileUpload = $this->dirUpload . '/' . $hash . '.hthl5upload';

        if ( 'GET' == $_SERVER["REQUEST_METHOD"] && isset($_GET['action']) ) {
            if ( 'abort' == $_GET["action"] ) {
                if ( is_file($fileUpload) ) {
                    unlink($fileUpload);
                }
                print "ok abort";

                closelog();
                return;
            }

            if ( 'done' == $_GET['action'] ) {
                if ( empty($_SERVER["HTTP_UPLOAD_FILENAME"]) ) {
                    print "error filename";

                    closelog();
                    return;
                }

                $filename = urldecode($_SERVER["HTTP_UPLOAD_FILENAME"]);
                $filename = BsmTranslit::translit($filename);
                $filename = basename($filename);
                rename($fileUpload, $this->dirUpload . '/' . $filename);

                syslog(LOG_INFO, "Finished for hash " . $hash);

                echo json_encode(array(
                    'filename' => $filename));
                return;
            }
        } elseif ( 'POST' == $_SERVER["REQUEST_METHOD"] ) { 
            syslog(LOG_INFO, "Uploading chunk. Hash ".$hash." (".intval($_SERVER["HTTP_PORTION_FROM"])."-".intval($_SERVER["HTTP_PORTION_FROM"]+$_SERVER["HTTP_PORTION_SIZE"]).", size: ".intval($_SERVER["HTTP_PORTION_SIZE"]).")");

            if ( 0 == intval($_SERVER["HTTP_PORTION_FROM"]) ) {
                $fout = fopen($fileUpload, "wb");
            } else {
                $fout = fopen($fileUpload, "ab");
            }

            if ( !$fout ) {
                syslog(LOG_INFO, "Can't open file for writing: ".$filename);
                header("HTTP/1.0 500 Internal Server Error");
                print "Can't open file for writing.";

                closelog();
                return;
            }

            $fin = fopen("php://input", "rb");
            if ( $fin ) {
                while ( !feof($fin) ) {
                    $data = fread($fin, 1024*1024);
                    fwrite($fout,$data);
                }

                fclose($fin);
            }

            fclose($fout);
        }

        header("HTTP/1.0 200 OK");
        print "ok\n";

        closelog();
        return;
    }
}