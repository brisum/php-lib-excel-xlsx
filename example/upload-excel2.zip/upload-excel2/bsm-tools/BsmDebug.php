<?php

class BsmDebug {
    private function __construct() {}

    public static function dump($var) {
        echo '<pre>';
        print_r($var);
        echo '</pre>';
    }
}
