<?php

require_once('init.php');
require_once('bsm-tools/file-manager/FileManager.php');

$hash = md5(time() . ' ' . mt_rand());

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html><head>
<title>longrun.com.ua</title>
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">

<link rel="stylesheet" type="text/css" href="./css/style.css">
<link rel="stylesheet" type="text/css" href="./bsm-tools/file-manager/style.css">

</head>
<body onload="ShowForm();">
	<div id="content">
    <a href="/administrator/upload-excel2/">
      UPLOAD EXCEL 2
    </a>
    <br />
    <br />
		<div class="bsm_fm_wr_form">
            <form id="bsm_fm_form" 
                  class="bsm_fm_form" 
                  method="post" 
                  action="./upload.php">
                <label for="bsm_fm_files">Виберіть файл:</label>
                <input type="file" 
                       id="bsm_fm_form_files" 
                       name="files[]" multiple />

                <fieldset>
                    <legend>Тип файлу:</legend>

                    <input type="radio" 
                           name="fileType" 
                           value="price" 
                           id="fileType_price" 
                           checked />
                    <label for="fileType_price">Прайс</label>
                    [<a href="/administrator/upload-excel2/example/Prais(priklad).xlsx" target="_blank">Приклад</a>]
                    <br />

                    <input type="radio" 
                           name="fileType" 
                           value="store_ak" 
                           id="fileType_store_ak" />
                    <label for="fileType_store_ak">Залишки AK</label>
                    [<a href="/administrator/upload-excel2/example/Ostatok-AK(priklad).xlsx" target="_blank">Приклад</a>]
                </fieldset>

                <input type="submit" value="Завантажити>>">
            </form>
            <div id="out">
                
            </div>
        </div>
	</div>

<script type="text/javascript" src="./js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="./bsm-tools/file-manager/FileUploader.js?nc=<?php print time();?>"></script>
<script type="text/javascript" src="./js/script.js"></script>
<script type="text/javascript">
	function ShowForm() {
		var uploader = new FileUploader({
			message_error: 'Ошибка при загрузке файла', 
			form: 'bsm_fm_form',
			formfiles: 'bsm_fm_form_files',
			uploadid: '<?php print $hash;?>',
			uploadscript: './upload.php',
			// redirect_success: './step2.php?hash=<?php print $hash;?>',
			// redirect_abort: './abort.php?hash=<?php print $hash;?>',
			portion: 1024*512, 
			loadSuccess: window['extract']
		});

		if ( !uploader || !uploader.CheckBrowser() ) {
			var e=document.getElementById('bsm_fm_form');
			
			if ( e )  {
				e.style.display='block';
			}
		}
	}
</script>

</body>
</html>