// Для начала определим метод XMLHttpRequest.sendAsBinary(),
// если он не определен (Например, для браузера Google Chrome). 
if ( !XMLHttpRequest.prototype.sendAsBinary ) {
    // XMLHttpRequest.prototype.sendAsBinary = function(datastr) {
    //     function byteValue(x) {
    //         return x.charCodeAt(0) & 0xff;
    //     }
    //     var ords = Array.prototype.map.call(datastr, byteValue);
    //     var ui8a = new Uint8Array(ords);

    //     this.send(ui8a.buffer);
    // }
    XMLHttpRequest.prototype.sendAsBinary = function(text){
      var data = new ArrayBuffer(text.length);
      var ui8a = new Uint8Array(data, 0);
      for (var i = 0; i < text.length; i++) ui8a[i] = (text.charCodeAt(i) & 0xff);
      this.send(ui8a);
    }
}

/**
 * Класс FileUploader.
 * @param ioptions Ассоциативный массив опций загрузки 
 * ioptions = {
 *   uploadscript,
 *   uploadid,
 *   portion,
 *   timeout,
 *   redirect_success,
 *   message_error,
 *   form,
 *   formfiles,
 * }
 */
function FileUploader(ioptions) {
    var that = this;

	this.files = null;
    this.options=ioptions;

	if ( undefined == this.options['uploadscript'] ) {
        return null;
    }

	/*
	* Проверка, поддерживает ли браузер необходимые объекты 
	* @return true, если браузер поддерживает все необходимые объекты
	*/
    this.CheckBrowser = function() {
        return (window.File && window.FileReader && window.FileList && 
            window.Blob);
    }


	/*
	* Загрузка части файла на сервер
	* @param from Позиция, с которой будем загружать файл
	*/
    this.UploadPortion = function(index, from, portion) {
        var file = that.files[index];
        var uploadId = that.options['uploadid'] + '_' + index;
        var reader = new FileReader();
        var blob = null;
        var xhrHttpTimeout = null;

		file.loadFrom = from;

        if ( file.size < (from + portion) ) {
            portion = file.size - from;
        }

        // console.log(index + ' ' + from + ' ' + portion);

		/*
		* Событие срабатывающее после чтения части файла в FileReader
		* @param evt Событие
		*/
        reader.onloadend = function(evt) {
            if ( evt.target.readyState == FileReader.DONE ) {
				var xhr = new XMLHttpRequest();

                xhr.open('POST', that.options['uploadscript'], true);
                xhr.setRequestHeader("Content-Type", "application/x-binary; charset=x-user-defined");

				xhr.setRequestHeader("Upload-Id", uploadId);
				xhr.setRequestHeader("Portion-From", from);
				xhr.setRequestHeader("Portion-Size", portion);

				that.xhrHttpTimeout = setTimeout(function() {
                    xhr.abort();
                },that.options['timeout']);

				/*
				* Событие XMLHttpRequest.onProcess. Отрисовка ProgressBar.
				* @param evt Событие
				*/
                xhr.upload.addEventListener("progress", function(evt) {
                    if ( !evt.lengthComputable ) {
                        return;
                    }

                    var loadSize = from + portion;
                    var percentComplete = Math.round((loadSize * 1000/file.size) / 10);
                    var out = document.getElementById(file.percentOutId);

                    // console.log('progress:' + from + ' ' + file.size + ' ' + percentComplete);

                    out.innerHTML = percentComplete + '%';
                }, false);

				/*
				* Событие XMLHttpRequest.onLoad. Окончание загрузки порции.
				* @param evt Событие
				*/
                xhr.addEventListener("load", function(evt) {
                    clearTimeout(that.xhrHttpTimeout);

					if ( evt.target.status != 200 ) {
                        alert( evt.target.responseText );
                        return;
                    }

					// Добавим к текущей позиции размер порции.
                    from += portion;

                    // console.log('load: ' + file.size + ' ' + from + ' ' + portion);

					// Закачаем следующую порцию, если файл еще не кончился.
                    if ( file.size > from ) {
                        that.UploadPortion(index, from, portion);
                    } else {
						var gxhr = new XMLHttpRequest();
                        var time = new Date().getTime();
                        var filename = time + '_' + encodeURIComponent(file.name);

                        var out = document.getElementById(file.percentOutId);
                        out.innerHTML = '100%';

                        gxhr.open('GET', that.options['uploadscript']+'?action=done', true);

                        gxhr.setRequestHeader("Upload-Id", uploadId);
						gxhr.setRequestHeader("Upload-Filename", filename);

						/*
						* Событие XMLHttpRequest.onLoad. Окончание загрузки сообщения об окончании загрузки файла :).
						* @param evt Событие
						*/
                        gxhr.addEventListener("load", function(evt) {
							if ( evt.target.status != 200) {
                                alert(evt.target.responseText.toString());
                                return;
                            } else {
                                var resp = JSON.parse(evt.target.responseText);
                                // else window.parent.location=that.options['redirect_success'];

                                if ( that.options['loadSuccess'] ) {
                                    that.options['loadSuccess'](resp);
                                }
                            }
                        }, false);

						// Отправим HTTP GET запрос
                        gxhr.sendAsBinary('');
                    }
                }, false);

				/*
				* Событие XMLHttpRequest.onError. Ошибка при загрузке
				* @param evt Событие
				*/
                xhr.addEventListener("error", function(evt) {
                    // Очистим таймаут
                    clearTimeout(that.xhrHttpTimeout);

					// Сообщим серверу об ошибке во время загруке, сервер сможет удалить уже загруженные части.
					// XMLHttpRequest, метод GET,  PHP скрипт тот-же.
                    var gxhr = new XMLHttpRequest();

                    gxhr.open('GET', that.options['uploadscript']+'?action=abort', true);

					// Установим идентификатор загруки.
                    gxhr.setRequestHeader("Upload-Id", uploadId);

					/*
					* Событие XMLHttpRequest.onLoad. Окончание загрузки сообщения об ошибке загрузки :).
					* @param evt Событие
					*/
                    gxhr.addEventListener("load", function(evt) {
						// Если сервер не вернул HTTP статус 200, то выведем окно с сообщением сервера.
                        if ( evt.target.status != 200) {
                            alert(evt.target.responseText);
                            return;
                        }
                    }, false);

					// Отправим HTTP GET запрос
                    gxhr.sendAsBinary('');

					// Отобразим сообщение об ошибке
                    if ( undefined == that.options['message_error'] ) {
                        alert("There was an error attempting to upload the file."); 
                    } else { 
                        alert(that.options['message_error']);
                    }
                }, false);

				/*
				* Событие XMLHttpRequest.onAbort. Если по какой-то причине передача прервана, повторим попытку.
				* @param evt Событие
				*/
                xhr.addEventListener("abort", function(evt) {
                    clearTimeout(that.xhrHttpTimeout);
                    that.UploadPortion(index, from, portion);
                }, false);

				// Отправим порцию методом POST
                xhr.sendAsBinary(evt.target.result);
            }
        };

		// Считаем порцию в объект Blob. Три условия для трех возможных определений Blob.[.*]slice().
        if ( file.slice ) {
            blob = file.slice(from, from + portion);
        } else if ( file.webkitSlice ) {
            blob = file.webkitSlice(from, from + portion);
        } else if ( file.mozSlice ) {
            blob = file.mozSlice(from, from + portion);
        }

		// Считаем Blob (часть файла) в FileReader
        reader.readAsBinaryString(blob);
    }


	/*
	* Загрузка файла на сервер
	* return Число. Если не 0, то произошла ошибка
	*/
    this.Upload = function() {
		// Скроем форму, чтобы пользователь не отправил файл дважды
        var e = document.getElementById(this.options['form']);

        if ( e ) {
            e.style.display = 'none';
        }

        if ( !this.files ) {
            return -1;
        }

        for ( i = this.files.length - 1; i >= 0; i-- ) {
            if ( this.files[i].size > this.options['portion'] ) {
                // Если размер файла больше размера порциии ограничимся одной порцией
                this.UploadPortion(i, 0, this.options['portion']);
            } else {
                // Иначе отправим файл целиком
                this.UploadPortion(i, 0, this.files[i].size);
            }
        }
    }

    this.init = function() {
        if ( !this.CheckBrowser() ) {
            alert('Ваш браузер не потдерживает загрузку.');
            return;
        }

        var form = document.getElementById(that.options['form']);

        // Установим значения по умолчанию
        if ( this.options['portion'] == undefined ) {
            this.options['portion'] = 1048576;
        }

        if ( this.options['timeout'] == undefined ) {
            this.options['timeout'] = 15000;
        }

        // Добавим обработку события выбора файла
        document.getElementById(this.options['formfiles']).addEventListener('change', function (evt) {
            that.files = evt.target.files;

            // console.log(that.files);
        }, false);

        // Добавим обратотку события onSubmit формы
        form.addEventListener('submit', function (evt) {
            for ( i = 0, len = that.files.length; i < len; i++ ) {
                var wrap = document.createElement("div");
                var percentOut = document.createElement("span");
                var file = that.files[i];

                wrap.id = 'bsm_fm_pb_' + i;
                wrap.innerHTML = file.name + ': ';
                percentOut.id = wrap.id + '_percent';
                percentOut.innerHTML = '0%';

                wrap.appendChild(percentOut);
                file.percentOutId = percentOut.id;

                if ( form.nextSibling ) {
                    form.parentNode.insertBefore(wrap, form.nextSibling);
                } else {
                   form.parentNode.appendChild(wrap);
                }
            }

            that.Upload();

            if ( arguments[0].preventDefault ) {
                arguments[0].preventDefault();
            } else {
                arguments[0].returnValue = false;
            }
        }, false);
    }

    this.init();
}