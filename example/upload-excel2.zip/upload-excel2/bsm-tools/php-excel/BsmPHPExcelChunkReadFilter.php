<?php

class BsmPHPExcelChunkReadFilter implements PHPExcel_Reader_IReadFilter {
    private $startHeaderRow = 0;
    private $endHeaderRow = 0;
    private $startRow = 0;
    private $endRow = 0;
    private $cols = array(1);

    public function setHeaderRows($startHeaderRow, $chunkSize) {
        $this->startHeaderRow = $startHeaderRow;
        $this->endHeaderRow = $startHeaderRow + $chunkSize;
    }

    public function setRows($startRow, $chunkSize) {
        $this->startRow = $startRow;
        $this->endRow = $startRow + $chunkSize;
    }

    public function setCols($start, $chunkSize) {
        $this->startRow = $startRow;
        $this->endRow = $startRow + $chunkSize;
    }

    public function readCell($column, $row, $worksheetName = '') {
        if ( !in_array($column, $this->cols) ) {
            return false;
        }
        
        if ( $row >= $this->startHeaderRow && $row < $this->endHeaderRow ) {
            return true;
        }
        if ( $row >= $this->startRow && $row < $this->endRow ) {
            return true;
        }
        return false;
    }
}
