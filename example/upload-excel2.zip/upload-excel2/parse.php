<?php

require_once('init.php');
require_once('bsm-tools/BsmDebug.php');
require_once('bsm-tools/BsmFileHelper.php');
require_once('bsm-tools/php-excel/BsmXlsx.php');

$resp = array(
    'status' => 'error', 
    'msg' => 'error run time',
    'filename' => '', 
    'fileType' => '', 
    'dirTmp' => '');
$fileTypes = array('price', 'store_ak');
$actions = array('extract', 'parse', 'clear');
$filename = '';
$fileType = '';
$action = '';

if ( empty($_POST['filename']) ) {
    $resp['msg'] = 'empty filename';
    echo json_encode($resp);
    die();
}
if ( empty($_POST['fileType']) || !in_array($_POST['fileType'], $fileTypes) ) {
    $resp['msg'] = 'empty fileType';
    echo json_encode($resp);
    die();
}
if ( empty($_POST['action']) || !in_array($_POST['action'], $actions) ) {
    $resp['msg'] = 'empty action';
    echo json_encode($resp);
    die();
}

$filename = basename($_POST['filename']);
$fileType = $_POST['fileType'];
$action = $_POST['action'];
$dirTmp = basename($_POST['dirTmp']);
$filepath = DIR_UPLOAD . '/' . $filename;
$xlsx = new BsmXlsx($filepath, DIR_UPLOAD . '/tmp/' . $dirTmp);

$resp['filename'] = $filename;
$resp['fileType'] = $fileType;
$resp['dirTmp'] = $dirTmp;

switch ( $action ) {
    case 'extract':
        $xlsx->extract();
        $resp['status'] = 'success';
        $resp['msg'] = htmlspecialchars('обробка ' . $filename, ENT_QUOTES);
        break;

    case 'parse':
        $perStep = 10000;
        $step = empty($_POST['step']) ? 1 : intval($_POST['step']);
        $startRow = 1 + ($step - 1) * $perStep;
        $isFirstStep = 1 == $step;
        $data = null;
        $mysqli = getMysqliDb();
        $affeccted = 0;

        if ( !$mysqli ) {
            $resp['msg'] = 'error connect to db';
            $resp['next'] = 'clear';
            break;
        }

        if ( $isFirstStep ) {
            $startRow += 1; // skip title
            $perStep -= 1;
        }

        if ( $isFirstStep && ('price' == $fileType) ) {
            clearPrice($mysqli);
        } elseif ( $isFirstStep && ('store_ak' == $fileType) ) {
            clearStoreAK($mysqli);
        }

        $xlsx->setRows($startRow, $perStep);
        switch ( $fileType ) {
            case 'price':
                $xlsx->setCols(1, 5);
                $data = $xlsx->data();
                $res = dataToPrice($mysqli, $data);
                break;

            case 'store_ak':
                $xlsx->setCols(1, 4);
                $data = $xlsx->data();
                $res = dataToStoreAK($mysqli, $data);
                break;
        }
        // $res = $res ? 'успішно' : 'помилка';
        // $res = '<pre>' . $res . '</pre>';

        if ( $perStep > count($data) ) {
            $resp['next'] = 'clear';
        } else {
            $resp['next'] = 'parse';
        }

        $resp['status'] = 'success';
        $resp['msg'] = "обробка з {$startRow} до " . ($startRow + $perStep - 1) . ' строк, оброблено: ' . count($data) . ', результат: ' . $res;

        // $resp['next'] = 'clear';
        break;

    case 'clear':
        $xlsx->clear();
        $resp['status'] = 'success';
        $resp['msg'] = 'очищення';
        break;
}

echo json_encode($resp);
die();
